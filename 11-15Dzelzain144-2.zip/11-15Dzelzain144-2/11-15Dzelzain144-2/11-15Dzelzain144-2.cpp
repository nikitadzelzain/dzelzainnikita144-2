﻿#include <iostream>
#include <memory>
using namespace std;

class Document {
public:
    virtual ~Document() = default;
    virtual void open() = 0;
    virtual void close() = 0;
};

class TextDocument : public Document {
public:
    void open() override { cout << "Open TextDocument\n"; }
    void close() override { cout << "Close TextDocument\n"; }
};

class SpreadsheetDocument : public Document {
public:
    void open() override { cout << "Open SpreadsheetDocument\n"; }
    void close() override { cout << "Close SpreadsheetDocument\n"; }
};

class Application {
public:
    virtual ~Application() = default;
    virtual unique_ptr<Document> createDocument() = 0;
};

class TextApplication : public Application {
public:
    unique_ptr<Document> createDocument() override {
        return make_unique<TextDocument>();
    }
};

class SheetApplication : public Application {
public:
    unique_ptr<Document> createDocument() override {
        return make_unique<SpreadsheetDocument>();
    }
};

int main() {
    Application* app = new TextApplication();
    auto doc = app->createDocument();
    doc->open();
    doc->close();
    delete app;

    app = new SheetApplication();
    doc = app->createDocument();
    doc->open();
    doc->close();
    delete app;

    return 0;
}
