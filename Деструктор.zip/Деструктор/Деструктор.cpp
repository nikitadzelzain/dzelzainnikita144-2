﻿#include <iostream>
using namespace std;

class Shape {
protected:
    int x, y;
public:
    Shape(int x = 0, int y = 0) : x(x), y(y) {
        cout << "Shape Constructor\n";
    }

    ~Shape() {
        cout << "Shape Destructor\n";
    }

    virtual void draw() const = 0;
};

class Rectangle : public Shape {
    int w, h;
public:
    Rectangle(int x, int y, int w, int h) : Shape(x, y), w(w), h(h) {
        cout << "Rectangle Constructor\n";
    }

    ~Rectangle() {
        cout << "Rectangle Destructor\n";
    }

    void draw() const override {
        cout << "Drawing Rectangle at (" << x << ", " << y
            << ") size " << w << "x" << h << "\n";
    }
};

int main() {
    Shape* s = new Rectangle(10, 5, 40, 20);
    delete s;   // удаляем через базовый указатель
    return 0;
}
