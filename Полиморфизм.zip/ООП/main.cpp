#include <iostream>
#include <vector>
using namespace std;

class Shape {
protected:
    int x, y;
public:
    Shape(int x = 0, int y = 0) : x(x), y(y) {}
    virtual ~Shape() = default;

    virtual void draw() const = 0;

    void move(int newX, int newY) {
        x = newX; y = newY;
        cout << "Moved Shape to (" << x << ", " << y << ")\n";
    }
};

class Rectangle : public Shape {
    int w, h;
public:
    Rectangle(int x, int y, int w, int h) : Shape(x, y), w(w), h(h) {}
    void draw() const override {
        cout << "Drawing Rectangle at (" << x << ", " << y
            << ") size " << w << "x" << h << "\n";
    }
};

class Circle : public Shape {
    int r;
public:
    Circle(int x, int y, int r) : Shape(x, y), r(r) {}
    void draw() const override {
        cout << "Drawing Circle at (" << x << ", " << y
            << ") radius " << r << "\n";
    }
};

int main() {
    vector<Shape*> shapes;
    shapes.push_back(new Rectangle(10, 5, 40, 20));
    shapes.push_back(new Circle(0, 0, 15));
    shapes.push_back(new Rectangle(-3, 7, 5, 5));

    for (size_t i = 0; i < shapes.size(); ++i) {
        shapes[i]->draw();
        shapes[i]->move(100 + 10 * int(i), 200 + 10 * int(i));
        shapes[i]->draw();
        cout << "----\n";
    }

    for (Shape* s : shapes) delete s;

    return 0;
}
